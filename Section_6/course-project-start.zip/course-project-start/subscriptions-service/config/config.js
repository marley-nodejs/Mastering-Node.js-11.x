module.exports = {
  development: {
    host: "localhost",
    username: "root",
    password: "123456789",
    port: 3308,
    database: "SubscriptionsDb",
    dialect: "mysql"
  },
  production: {
    host: "localhost",
    username: "root",
    password: "123456789",
    port: 3308,
    database: "SubscriptionsDb",
    dialect: "mysql"
  }
}