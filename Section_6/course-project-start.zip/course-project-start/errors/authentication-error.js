module.exports = class AuthenticationError {
    constructor(message) {
        this.message = message;
    }
}